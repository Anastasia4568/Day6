﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using WSUniversalLib;

namespace WSUniversalLibUnitTestProject
{
    [TestClass]
    public class UnitTest
    {
        [TestMethod]
        //Проверка метода, когда передан несуществующий тип продукта
        public void NonExistentProductType()
        {
            // Тип продукта 6 не существует
            int productType = 6;
            int materialType = 1;
            int count = 1;
            float width = 10;
            float height = 20;

            Calculation calculation = new Calculation();
            int quantity = calculation.GetQuantityForProduct(productType, materialType, count, width, height);

            // Первое значение — то, что мы ожидаем от метода
            // Второе значение — то, что метод вернул во время теста
            Assert.AreEqual(-1, quantity);
        }

        [TestMethod]
        //Проверка метода, когда передан несуществующий тип материала
        public void NonExistentMaterialType()
        {
            // Тип материала 288 не существует
            int productType = 2;
            int materialType = 288;
            int count = 1;
            float width = 10;
            float height = 20;

            Calculation calculation = new Calculation();
            int quantity = calculation.GetQuantityForProduct(productType, materialType, count, width, height);

            // Первое значение — то, что мы ожидаем от метода
            // Второе значение — то, что метод вернул во время теста
            Assert.AreEqual(-1, quantity);
        }

        [TestMethod]
        //Проверка метода, когда передан отрицательный тип продукции
        public void NonExisteNtnegativeProductType()
        {
            int productType = -11;
            int materialType = 1;
            int count = 1;
            float width = 10;
            float height = 20;

            Calculation calculation = new Calculation();
            int quantity = calculation.GetQuantityForProduct(productType, materialType, count, width, height);

            // Первое значение — то, что мы ожидаем от метода
            // Второе значение — то, что метод вернул во время теста
            Assert.AreEqual(-1, quantity);
        }

        [TestMethod]
        //Проверка метода, когда передан отрицательный тип материала
        public void NonExisteNtnegativeMaterialType()
        {
            int productType = -11;
            int materialType = 1;
            int count = 1;
            float width = 10;
            float height = 20;

            Calculation calculation = new Calculation();
            int quantity = calculation.GetQuantityForProduct(productType, materialType, count, width, height);

            // Первое значение — то, что мы ожидаем от метода
            // Второе значение — то, что метод вернул во время теста
            Assert.AreEqual(-1, quantity);
        }

        [TestMethod]
        //Проверка метода, когда передана отрицательная ширина
        public void NonExisteNtnegativeWidth()
        {
            int productType = 1;
            int materialType = 1;
            int count = 1;
            float width = -10;
            float height = 20;

            Calculation calculation = new Calculation();
            int quantity = calculation.GetQuantityForProduct(productType, materialType, count, width, height);

            // Первое значение — то, что мы ожидаем от метода
            // Второе значение — то, что метод вернул во время теста
            Assert.AreEqual(-1, quantity);
        }

        [TestMethod]
        //Проверка метода, когда передана отрицательная длина
        public void NonExisteNtnegativeHeight()
        {
            int productType = 1;
            int materialType = 1;
            int count = 1;
            float width = 10;
            float height = -20;

            Calculation calculation = new Calculation();
            int quantity = calculation.GetQuantityForProduct(productType, materialType, count, width, height);

            // Первое значение — то, что мы ожидаем от метода
            // Второе значение — то, что метод вернул во время теста
            Assert.AreEqual(-1, quantity);
        }

        [TestMethod]
        //Проверка метода, когда передано отрицательная количество единиц продукции
        public void NonExisteNtnegativeCount()
        {
            int productType = 1;
            int materialType = 1;
            int count = -41;
            float width = 10;
            float height = 20;

            Calculation calculation = new Calculation();
            int quantity = calculation.GetQuantityForProduct(productType, materialType, count, width, height);

            // Первое значение — то, что мы ожидаем от метода
            // Второе значение — то, что метод вернул во время теста
            Assert.AreEqual(-1, quantity);
        }

        [TestMethod]
        //Проверка метода, когда переданы все верные данные
        public void AllArgumentsGood()
        {
            int productType = 3;
            int materialType = 1;
            int count = 15;
            float width = 20;
            float height = 45;

            Calculation calculation = new Calculation();
            int quantity = calculation.GetQuantityForProduct(productType, materialType, count, width, height);

            // Первое значение — то, что мы ожидаем от метода
            // Второе значение — то, что метод вернул во время теста
            Assert.AreEqual(quantity, quantity);
        }

        [TestMethod]
        //Проверка метода, когда переданы данные о первом типе продукта и материала
        public void FirstProductTypeAndFirstMaterialType()
        {
            int productType = 1;
            int materialType = 1;
            int count = 15;
            float width = 20;
            float height = 45;

            Calculation calculation = new Calculation();
            int quantity = calculation.GetQuantityForProduct(productType, materialType, count, width, height);

            // Первое значение — то, что мы ожидаем от метода
            // Второе значение — то, что метод вернул во время теста
            Assert.AreEqual(quantity, quantity);
        }

        [TestMethod]
        //Проверка метода, когда переданы данные большого количества единиц продукции
        public void LargeCountProducts()
        {
            int productType = 3;
            int materialType = 1;
            int count = 1000;
            float width = 10;
            float height = 15;

            Calculation calculation = new Calculation();
            int quantity = calculation.GetQuantityForProduct(productType, materialType, count, width, height);

            // Первое значение — то, что мы ожидаем от метода
            // Второе значение — то, что метод вернул во время теста
            Assert.AreEqual(quantity, quantity);
        }
    }
}
